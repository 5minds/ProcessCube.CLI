#!/bin/bash

atlas remove-process-models BuchAusleihen_erfolgreich BuchAusleihen_fehlerhaft BuchAusleihen_laufend --yes